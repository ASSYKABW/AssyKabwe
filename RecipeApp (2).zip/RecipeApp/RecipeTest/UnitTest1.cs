namespace RecipeTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        // This is a unit test method named TestMethod1. It tests the CalculateTotalColories method.
        public void TestMethod1()
        {
            // Define an array of numbers representing calories.
            double[] Number = { 100, 30, 8, 10, 58 };
            // Call the CalculateTotalColories method with the array of numbers and store the result.
            double Result = CalculateTotalColories(Number);

            // Use the Assert.AreEqual method to verify that the result matches the expected value.
            Assert.AreEqual(206, Result);
        }
        // This method calculates the total number of calories from an array of calorie values.
        public double CalculateTotalColories(double[] Calories)
        {
            // Initialize a variable to store the result.
            double Result = 0;

            // Loop through each calorie value in the array and add it to the result.
            for (int i = 0; i < Calories.Length; i++)
            {
                Result += Calories[i];
            }

            // Return the total number of calories.
            return Result;
        }

    }
}