﻿// See https://aka.ms/new-console-template for more information
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.Metrics;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Transactions;
internal class Program
{
    static void Main(string[] args)
    {
        // Create a dictionary to store recipes
        Dictionary<string, Recipe> DictionaryRecipe = new Dictionary<string, Recipe>();
        // Create an instance of the MainMenu class and pass the dictionary of recipes to it
        MainMenu main = new MainMenu(DictionaryRecipe);
        // Call the mainMenu method to display the main menu and start the application
        main.mainMenu();
    }

    class RecipeLogger
    {
        private Dictionary<string, Recipe> DictionaryRecipe;
        // Constructor to initialize the RecipeLogger with a dictionary of recipes
        public RecipeLogger(Dictionary<string, Recipe> DictionaryRecipe)
        {
            this.DictionaryRecipe = DictionaryRecipe;
        }
        // Method to prompt the user to enter details for multiple recipes
        public void EnterDetailRecipe()
        {
            // Prompt the user to enter the number of recipes
            Console.Write("Enter the number of recipes: ");
            int NumberRecipe;
            if (int.TryParse(Console.ReadLine(), out NumberRecipe))
            {
                for (int i = 0; i < NumberRecipe; i++)
                {
                    // prompt the user to enter the name of the recipe
                    Console.Write("Enter The name of the recipe: ");
                    string RecipeName = Console.ReadLine();
                    // Create a new instance of the Recipe class
                    Recipe recipe = new Recipe();
                    // Call the EnterDetails method of the Recipe class to enter recipe details
                    recipe.EnterDetails();
                    // Add the recipe to the dictionary with its name as the key
                    DictionaryRecipe.Add(RecipeName, recipe);
                }
                string Answer;
                // Display ingredients and steps for each recipe or return to main menu based on user input
                    do
                    {
                    Console.Write("Do you want to Display the ingredients and steps? (Y/N): ");
                    Answer = Console.ReadLine();
                    switch (Answer)
                    {
                        case "Y":
                            foreach (var RecipeEntry in DictionaryRecipe)
                            {
                                Console.Write($"Recipe Name: {RecipeEntry.Key}");
                                RecipeEntry.Value.DisplayRecipe();
                            }
                            break;
                        case "N":
                            MainMenu main = new MainMenu(DictionaryRecipe);
                            main.mainMenu();
                            break;
                        default:
                            Console.WriteLine("Please enter a valid input");
                            break;
                    }
                } while (Answer != "N");
            }
            else
            {
                Console.WriteLine("Please enter a number");
            }
        }
        // Method to display the names of all recipes in the dictionary
        public void DisplayRecipe()
        {
            foreach (var RecipeEntry in DictionaryRecipe)
            {
                Console.WriteLine($"Recipe name: {RecipeEntry.Key}");
            }
        }
        // Method to search for a recipe by name and display its details
        public void SearchRecipe()
        {
            Console.Write("Plase enter the recipe name: ");
            string RecipeName = Console.ReadLine();
            if (DictionaryRecipe.ContainsKey(RecipeName))
            {
                Console.WriteLine($"Recipe name: {RecipeName}");
                DictionaryRecipe[RecipeName].DisplayRecipe();
            }
            else
            {
                Console.WriteLine("Recipe does not exist!!");
            }
        }
    }
    class IngredientMenu
    {
        private Dictionary<string, Recipe> DictionaryRecipe;
        public IngredientMenu(Dictionary<string, Recipe> DictionaryRecipe)
        {
            this.DictionaryRecipe = DictionaryRecipe;
            Recipe recipe = new Recipe();

            // main loop
            while (true)
            {
                // Display menu options
                Console.WriteLine("Welcome to Recipe App");
                Console.WriteLine(".......................................................");
                Console.WriteLine("Enter 0 to Enter The Details For a Single Recipe");
                Console.WriteLine("Enter 1 to Display the Full Recipe");
                Console.WriteLine("Enter 2 to Request a Scale Recipe");
                Console.WriteLine("Enter 3 to Reset the Quantities to the Original Values");
                Console.WriteLine("Enter 4 to Clear the Recipe");
                Console.WriteLine("Enter 5 to go back to main menu");
                Console.WriteLine(".......................................................");
                //This line of code allow to enter a number form 0 to 5
                for (int i = 0; i < 5; i++)
                {
                    // Allow the user to enter a number
                    Console.Write("Please Choice Between 0 to 5: ");
                    int Enter = Convert.ToInt32(Console.ReadLine());

                    // allow a user to enter the details
                    if (Enter == 0)
                    {
                        recipe.EnterDetails();
                    }
                    // allow the user to display the recipe
                    if (Enter == 1)
                    {
                        recipe.DisplayRecipe();
                    }
                    // allow the user to request scale recipe
                    if (Enter == 2)
                    {
                        Console.Write("Enter Scale Factor '0.5,2 or 3': ");
                        double Factor = double.Parse(Console.ReadLine());
                        recipe.ScaleRecipe(Factor);
                        Console.WriteLine("New Ingredient Quantity: " + Factor);
                    }
                    // allow the user to reset the quantity
                    if (Enter == 3)
                    {
                        recipe.ResetQuantities();
                    }
                    // allow the user to clear the recipe
                    if (Enter == 4)
                    {
                        recipe.ClearRecipe();
                    }
                    // allow the user to exit the recipe app
                    if (Enter == 5)
                    {
                        MainMenu main = new MainMenu(DictionaryRecipe);
                        main.mainMenu();
                    }
                    // this line of code allow the user to re-enter a number
                    else
                    {
                        Console.WriteLine("You have entered the wrong number; Please enter a number 0 to 5!! ");
                    }
                }
            }
        }
    }
    class Recipe
    {
        // Private fields to store Name, Quantity, Unit of Measurement, and Each Step.
        private string[] NameIngredients;
        private double[] IngredientQuantity;
        private string[] UnitOfMeasurement;
        private string[] EachStep;
        private double[] Calories;
        private string[] FoodGroup;

        // Constructor to initial empty recipe
        public Recipe()
        {
            // Initialize empty arrays for name, quantity, unit of measurement, and step.
            NameIngredients = new string[0];
            IngredientQuantity = new double[0];
            UnitOfMeasurement = new string[0];
            EachStep = new string[0];
            Calories = new double[0];
            FoodGroup = new string[0];
        }
        // A method to enter details of a single recipe.
        public void EnterDetails()
        {
            // Prompt the user to enter the number of ingredients
            Console.Write("Please enter the number of Ingredients: ");
            int NumberOfIngredients = Convert.ToInt32(Console.ReadLine());

            // Initialize the arrays with the correct size.
            NameIngredients = new string[NumberOfIngredients];
            IngredientQuantity = new double[NumberOfIngredients];
            UnitOfMeasurement = new string[NumberOfIngredients];
            EachStep = new string[NumberOfIngredients];
            Calories = new double[NumberOfIngredients];
            FoodGroup = new string[NumberOfIngredients];

            // Prompt the user to enter the details of each ingredients.
            for (int i = 0; i < NumberOfIngredients; i++)
            {
                Console.WriteLine($"Enter ingredient detail {i + 1}");
                Console.Write("Please enter Ingredient Name: ");
                NameIngredients[i] = Console.ReadLine();
                do
                {
                    Console.Write("Enter Ingredient Quantity: ");
                }
                while (!double.TryParse(Console.ReadLine(), out IngredientQuantity[i]));
                Console.Write("Enter Ingredient Unit Of Measurement: ");
                UnitOfMeasurement[i] = Console.ReadLine();
                do
                {
                    Console.Write("Enter the number of calories: ");
                }
                while (!double.TryParse(Console.ReadLine(), out Calories[i]));
                Console.Write("Enter food group: ");
                FoodGroup[i] = Console.ReadLine();
            }
            // delegation
            double calExceed = CalculateTotalCalorie(Calories);
            Console.WriteLine("Total Calories: " + calExceed);
            if (calExceed > 300)
            {
                Console.WriteLine("Total calories exceed 300!!!");
            }

            // Prompt the user to enter the number of steps.
            int NumberOfSteps;
            do
            {
                Console.Write("Please enter the Number Of Steps: ");
            }
            while (!int.TryParse(Console.ReadLine(), out NumberOfSteps));
            EachStep = new string[NumberOfSteps];
            // Prompt the user to enter the descriptions of each step.
            for (int a = 0; a < NumberOfSteps; a++)
            {
                Console.WriteLine($"steps {a + 1}");
                Console.Write("Please enter a description of each step: ");
                EachStep[a] = Console.ReadLine();
            }
        }
        // Calculate total calories and check if it exceeds 300
        public double CalculateTotalCalorie(double[] Calories)
        {
            double TotalCalorie = 0;
            for (int i = 0; i < Calories.Length; i++)
            {
                TotalCalorie += Calories[i];
            }
            return TotalCalorie;
        }

        // A method to display the full recipe.
        public void DisplayRecipe()
        {
            Console.WriteLine("Display Full Recipe");
            Console.WriteLine("...................");
            //Display the full recipe.
            Console.WriteLine("Ingredients");
            Console.WriteLine("...........");
            for (int a = 0; a < NameIngredients.Length; a++)
            {
                Console.WriteLine($"{IngredientQuantity[a]} {UnitOfMeasurement[a]} of {NameIngredients[a]}");
            }
            Console.WriteLine("Steps");
            Console.WriteLine("......");
            for (int i = 0; i < EachStep.Length; i++)
            {
                Console.WriteLine($"{EachStep[i]}");
            }
            double TotalCalorie = 0;
            for (int i = 0; i < Calories.Length; i++)
            {
                TotalCalorie += Calories[i];
            }
            if (TotalCalorie > 300)
            {
                Console.WriteLine("Total calories exceed 300!!!");
            }

        }

        // A method to scale recipe.
        public void ScaleRecipe(double Factor)
        {
            Console.WriteLine("Request a Scale Recipe");
            Console.WriteLine("......................");
            // to multiply all the Ingredient Quantity by scale factor.
            for (int i = 0; i < IngredientQuantity.Length; i++)
            {
                IngredientQuantity[i] *= Factor;
            }
        }
        // A method to reset the Ingredient Quantity to the orginal.
        public void ResetQuantities()
        {
            Console.WriteLine("Reste the Quantiies to the Orginal Value");
            Console.WriteLine("........................................");
            for (int i = 0; i < IngredientQuantity.Length; i++)
            {
                IngredientQuantity[i] /= 2;
            }
        }

        //A method to Clear All the Data and enter the new Recipe.
        public void ClearRecipe()
        {
            Console.WriteLine("Clear The Recipe");
            Console.WriteLine("................");
            //Clear all the recipe.
            NameIngredients = new string[0];
            IngredientQuantity = new double[0];
            UnitOfMeasurement = new string[0];
            EachStep = new string[0];
            Console.WriteLine("You have Succefully Delete the Recipe");
        }


    }
    class MainMenu
    {
        // Private fields to store the dictionary of recipes and an instance of RecipeLogger
        private Dictionary<string, Recipe> DictionaryRecipe;
        private RecipeLogger Display;
        // Constructor to initialize the MainMenu with the dictionary of recipes
        public MainMenu(Dictionary<string, Recipe> DictionaryRecipe)
        {
            this.DictionaryRecipe = DictionaryRecipe;
            // Create an instance of RecipeLogger and pass the dictionary of recipes to it
            Display = new RecipeLogger(DictionaryRecipe);
        }
        // Method to display the main menu and handle user input
        public void mainMenu()
        {
            // Display the menu repeatedly until the user chooses to exit
            while (true)
            {
                Console.WriteLine("---------------------------------------------");
                Console.WriteLine("Welcome to Recipe App");
                Console.WriteLine("---------------------------------------------");
                Console.WriteLine("1) Enter Recipe Details");
                Console.WriteLine("2) Display Recipe");
                Console.WriteLine("3) Search Recipe");
                Console.WriteLine("4) Exit application");
                Console.WriteLine("---------------------------------------------");
                Console.Write("Please select 1 to 4: ");
                string Answer = Console.ReadLine();
                switch (Answer)
                {
                    case "1":
                        // Call the EnterDetailRecipe method of RecipeLogger to enter recipe details
                        Display.EnterDetailRecipe();
                        break;
                    case "2":
                        // Call the DisplayRecipe method of RecipeLogger to display recipes
                        Display.DisplayRecipe();
                        break;
                    case "3":
                        // Call the SearchRecipe method of RecipeLogger to search for a recipe
                        Display.SearchRecipe();
                        break;
                    case "4":
                        // Exit the application
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Plaese enter a valid input");
                        break;
                }
            }
        }
    }
}


        
     

 
    